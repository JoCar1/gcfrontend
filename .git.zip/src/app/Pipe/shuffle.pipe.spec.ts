import { ShufflePipe } from './shuffle.pipe';

describe('ShufflePipe', () => {
  it('create an instance', () => {
    const pipe = new ShufflePipe();
    expect(pipe).toBeTruthy();
  });
});
