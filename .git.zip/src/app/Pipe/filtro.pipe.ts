import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filtro'
})
export class FiltroPipe implements PipeTransform {

  transform(arreglo: any[], texto: string): any[] {
    let txt = texto+'';
    if (txt === '') {
        return arreglo;
    }
    console.log(txt);
    txt = txt.toLowerCase();
  return arreglo.filter(item => {
    // if(item.direccion){
    //   return item.direccion.toLowerCase().includes(txt);
    // }else{
      return item.nombre.toLowerCase().includes(txt);
    // }
    
  });
  }


}
