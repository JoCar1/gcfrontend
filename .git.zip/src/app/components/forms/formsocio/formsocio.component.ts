import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Isocio } from '../../../models/interfaces';
import { Restangular } from "ngx-restangular";
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-formsocio',
  templateUrl: './formsocio.component.html',
  styleUrls: ['./formsocio.component.scss']
})
export class FormsocioComponent implements OnInit {
  action: string;
  socio: Isocio;
  dataForm: FormGroup;
  dialogTitle: string;
  hide = true;
  ngx:Restangular;
  constructor(
    public matDialogRef: MatDialogRef<FormsocioComponent>,
    @Inject(MAT_DIALOG_DATA) private _data: any,
    private _formBuilder: FormBuilder,
    public restangular: Restangular,
    private spinner: NgxSpinnerService,
    public snackBar: MatSnackBar
  )
  {
    this.ngx = this.restangular.all('socio');
    console.log(_data);
    // Set the defaults
    this.action = _data.accion;
    this.socio = _data.data;
    console.log(this.socio);
    
    if ( this.action === 'edit' )
    {
        this.dialogTitle = 'Editar Socio';
        // this.socio = _data.data;
    }
    else
    {
        this.dialogTitle = 'Agregar Socio';
        // this. = new Contact({});
    }

    this.dataForm = this.createContactForm();
  }

  ngOnInit() {
    
  }
  createContactForm(): FormGroup
  {
      return this._formBuilder.group({
          id      : [this.socio.id],
          nombre    : [this.socio.nombre],
          pais: [this.socio.pais],
          ciudad  : [this.socio.ciudad],
          direccion  : [this.socio.direccion],
          web: [this.socio.web],
          contacto : [this.socio.contacto],
          telefono: [this.socio.telefono],
          celular   : [this.socio.celular],
          email   : [this.socio.email],
          nit   : [this.socio.nit],
      });
  }

  guardar(){
    // this.matDialogRef.close();
    this.spinner.show();
    const data1 = this.dataForm.value;
    // console.log(data1);
    switch (this.action) {
      case "add":
          this.ngx.post(data1).subscribe(
          (response) => {
            console.log(response);
            this.spinner.hide();
            this.cancelar();
            this.snackBar.open(response.mensaje, ':-)', {
              duration: 3000,
            });
          },
          ()=>{
            this.spinner.hide();
          });
        break;
      case "edit":
        this.ngx.customPUT(data1,data1.id).subscribe(
          (response) => {
            console.log(response);
            this.spinner.hide();
            this.snackBar.open(response.mensaje, ':-)', {
              duration: 3000,
            });
          },
          ()=>{
            this.spinner.hide();
          });
        break;
    }
  }
  cancelar(){
    this.dataForm.reset();
    this.dataForm.patchValue({
    	// descripcion: ''
    });
  }

}
